#!/bin/bash

python3 main.py "$@"
